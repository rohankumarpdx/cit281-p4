const fastify=require("fastify")();
//GetrouteandJSON/objectreply
fastify.get("/cit",(request,reply)=>
{
    reply.code(200).header("Content-Type","application/json;charset=utf-8").send({test:"Thisisatest"});
});
//StartserverandlistentorequestsusingFastify
const listenIP="localhost";const listenPort=8082;fastify.listen(listenPort,listenIP,(err,address)=>
{
    if(err){console.log(err);process.exit(1);}console.log(`Serverlisteningon${address}`);
});